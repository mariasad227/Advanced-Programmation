<form action="../backend/student.php" method="POST" enctype="multipart/form-data">
    <input type="hidden" name="session_id" value="<?= $_GET['id'] ?>">

    <label>Upload justification (PDF, JPG, PNG)</label>
    <input type="file" name="justification" required>

    <button class="btn">Submit</button>
</form>
