<?php
session_start();
require_once __DIR__ . "/../backend/db.php";
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'student') {
    header("Location: ../index.html");
    exit;
}
$student_id = $_SESSION['user_id'];

// Fetch groups the student belongs to
$stmt = $conn->prepare("
    SELECT sg.id as group_id, sg.name as group_name, c.name as course_name
    FROM student_groups sg
    JOIN courses c ON c.id = sg.course_id
    JOIN group_students gs ON gs.group_id = sg.id
    WHERE gs.student_id = ?
");
$stmt->execute([$student_id]);
$groups = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>Student Home</title>
  <link rel="stylesheet" href="../style.css">
</head>
<body>
  <header><a href="../backend/logout.php">Logout</a></header>
  <main class="container">
    <h2>Welcome, <?= htmlspecialchars($_SESSION['first_name']) ?></h2>
    <h3>Your Groups</h3>
    <ul>
      <?php foreach($groups as $g): ?>
        <li>
          <?= htmlspecialchars($g['course_name']) ?> - <?= htmlspecialchars($g['group_name']) ?>
          <a href="attendance.php?group_id=<?= $g['group_id'] ?>">View attendance</a>
        </li>
      <?php endforeach; ?>
    </ul>
  </main>
</body>
</html>
