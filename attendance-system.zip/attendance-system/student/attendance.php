<?php
session_start();
require_once __DIR__ . "/../backend/db.php";
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'student') {
    header("Location: ../index.html");
    exit;
}
$group_id = intval($_GET['group_id'] ?? 0);
$student_id = $_SESSION['user_id'];

// Sessions for the group
$stmt = $conn->prepare("SELECT * FROM sessions WHERE group_id = ? ORDER BY session_date DESC");
$stmt->execute([$group_id]);
$sessions = $stmt->fetchAll(PDO::FETCH_ASSOC);

// attendance per session
$attStmt = $conn->prepare("SELECT attended, participation FROM attendance WHERE session_id = ? AND student_id = ?");

?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>Attendance</title>
  <link rel="stylesheet" href="../style.css">
</head>
<body>
  <header><a href="../backend/logout.php">Logout</a></header>
  <main class="container">
    <h2>Your Attendance</h2>
    <table>
      <thead><tr><th>Date</th><th>Attended</th><th>Participation</th><th>Justify</th></tr></thead>
      <tbody>
      <?php foreach($sessions as $s):
        $attStmt->execute([$s['id'], $student_id]);
        $rec = $attStmt->fetch(PDO::FETCH_ASSOC);
        $attended = $rec ? ($rec['attended'] ? 'Yes' : 'No') : 'No Record';
        $part = $rec ? intval($rec['participation']) : 0;
      ?>
      <tr>
        <td><?= htmlspecialchars($s['session_date']) ?></td>
        <td><?= $attended ?></td>
        <td><?= $part ?></td>
        <td>
          <?php if(!$rec || !$rec['attended']): ?>
            <form action="../backend/student.php" method="POST" enctype="multipart/form-data" style="display:inline-block">
              <input type="hidden" name="session_id" value="<?= $s['id'] ?>">
              <input type="file" name="justification" required>
              <button class="btn" type="submit">Upload</button>
            </form>
          <?php else: ?>
            -
          <?php endif; ?>
        </td>
      </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </main>
</body>
</html>
