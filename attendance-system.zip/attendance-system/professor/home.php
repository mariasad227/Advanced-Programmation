<?php
session_start();
require_once __DIR__ . "/../backend/db.php";
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'professor') {
    header("Location: ../index.html");
    exit;
}

// Simple listing: groups & sessions for professor (for demo we list all)
$stmt = $conn->query("SELECT s.*, sg.name as group_name, c.name as course_name FROM sessions s JOIN student_groups sg ON sg.id = s.group_id JOIN courses c ON c.id = sg.course_id ORDER BY s.session_date DESC");
$sessions = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>Professor Home</title>
  <link rel="stylesheet" href="../style.css">
</head>
<body>
  <header><a href="../backend/logout.php">Logout</a></header>
  <main class="container">
    <h2>Professor Dashboard</h2>
    <h3>Sessions</h3>
    <ul>
      <?php foreach($sessions as $s): ?>
        <li>
          <?= htmlspecialchars($s['course_name']) ?> - <?= htmlspecialchars($s['group_name']) ?> (<?= $s['session_date'] ?>)
          <a href="session.php?id=<?= $s['id'] ?>">Mark Attendance</a>
          <a href="summary.php?group_id=<?= $s['group_id'] ?>">Summary</a>
        </li>
      <?php endforeach; ?>
    </ul>
  </main>
</body>
</html>
