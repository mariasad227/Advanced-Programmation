<?php
session_start();
require_once __DIR__ . "/../backend/db.php";
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'professor') {
    header("Location: ../index.html");
    exit;
}

$session_id = intval($_GET['id']);
if ($session_id <= 0) { header("Location: home.php"); exit; }

// get students in the group
$st = $conn->prepare("
  SELECT u.id, u.first_name, u.last_name
  FROM users u
  JOIN group_students gs ON gs.student_id = u.id
  JOIN sessions s ON s.group_id = gs.group_id
  WHERE s.id = ?
");
$st->execute([$session_id]);
$students = $st->fetchAll(PDO::FETCH_ASSOC);

// get existing attendance if any
$attStmt = $conn->prepare("SELECT attended, participation FROM attendance WHERE session_id = ? AND student_id = ?");

?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>Mark Attendance</title>
  <link rel="stylesheet" href="../style.css">
</head>
<body>
  <header><a href="../backend/logout.php">Logout</a></header>
  <main class="container">
    <h2>Mark Attendance for Session #<?= $session_id ?></h2>
    <form action="../backend/professor.php" method="POST">
      <input type="hidden" name="session_id" value="<?= $session_id ?>">
      <table>
        <thead><tr><th>Name</th><th>Attended</th><th>Participation (0-6)</th></tr></thead>
        <tbody>
        <?php foreach($students as $s):
          $attStmt->execute([$session_id, $s['id']]);
          $rec = $attStmt->fetch(PDO::FETCH_ASSOC);
          $participation = $rec ? intval($rec['participation']) : 0;
          $checked = $rec && $rec['attended'] ? 'checked' : '';
        ?>
        <tr>
          <td><?= htmlspecialchars($s['last_name']) . ' ' . htmlspecialchars($s['first_name']) ?></td>
          <td><input type="checkbox" name="attend[<?= $s['id'] ?>]" <?= $checked ?>></td>
          <td><input type="number" name="part[<?= $s['id'] ?>]" min="0" max="6" value="<?= $participation ?>"></td>
        </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
      <button class="btn" type="submit">Save Attendance</button>
    </form>
  </main>
</body>
</html>
