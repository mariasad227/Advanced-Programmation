<?php
session_start();
require_once __DIR__ . "/../backend/db.php";
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'professor') {
    header("Location: ../index.html");
    exit;
}
$group_id = intval($_GET['group_id'] ?? 0);
if ($group_id <= 0) { header("Location: home.php"); exit; }

// Get students & their aggregated attendance/participation across sessions
$sql = "
SELECT u.id, u.first_name, u.last_name,
 SUM(CASE WHEN a.attended = 0 OR a.attended IS NULL THEN 1 ELSE 0 END) AS absences,
 SUM(a.participation) AS total_participation
FROM users u
JOIN group_students gs ON gs.student_id = u.id
LEFT JOIN attendance a ON a.student_id = u.id
LEFT JOIN sessions s ON s.id = a.session_id AND s.group_id = ?
WHERE gs.group_id = ?
GROUP BY u.id
";
$stmt = $conn->prepare($sql);
$stmt->execute([$group_id, $group_id]);
$rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>Summary</title>
  <link rel="stylesheet" href="../style.css">
</head>
<body>
  <header><a href="../backend/logout.php">Logout</a></header>
  <main class="container">
    <h2>Attendance Summary</h2>
    <table>
      <thead><tr><th>Name</th><th>Absences</th><th>Total Participation</th></tr></thead>
      <tbody>
      <?php foreach($rows as $r): ?>
        <tr <?php
            $abs = intval($r['absences']);
            if ($abs < 3) echo 'class="attendance-green"';
            elseif ($abs <= 4) echo 'class="attendance-yellow"';
            else echo 'class="attendance-red"';
        ?>>
          <td><?= htmlspecialchars($r['last_name']) . ' ' . htmlspecialchars($r['first_name']) ?></td>
          <td><?= $abs ?></td>
          <td><?= intval($r['total_participation']) ?></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </main>
</body>
</html>
