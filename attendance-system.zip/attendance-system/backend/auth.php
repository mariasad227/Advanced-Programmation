<?php
// backend/auth.php
session_start();
require_once __DIR__ . "/db.php";

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: ../index.html");
    exit;
}

$email = filter_var($_POST['email'] ?? '', FILTER_VALIDATE_EMAIL);
$password = $_POST['password'] ?? '';

if (!$email || !$password) {
    header("Location: ../index.html?error=credentials");
    exit;
}

$stmt = $conn->prepare("SELECT id, email, password, role, first_name, last_name FROM users WHERE email = ? LIMIT 1");
$stmt->execute([$email]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$user || !password_verify($password, $user['password'])) {
    header("Location: ../index.html?error=credentials");
    exit;
}

// login success
$_SESSION['user_id'] = $user['id'];
$_SESSION['role'] = $user['role'];
$_SESSION['first_name'] = $user['first_name'];
$_SESSION['last_name'] = $user['last_name'];

switch ($user['role']) {
    case 'admin':
        header("Location: ../admin/home.php");
        break;
    case 'professor':
        header("Location: ../professor/home.php");
        break;
    case 'student':
        header("Location: ../student/home.php");
        break;
    default:
        header("Location: ../index.html");
        break;
}
exit;
