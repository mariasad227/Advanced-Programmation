<?php
// backend/student.php
session_start();
require_once __DIR__ . "/db.php";

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'student') {
    header('HTTP/1.1 403 Forbidden');
    exit('Access denied');
}

$student_id = $_SESSION['user_id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Handle justification upload
    if (!isset($_POST['session_id']) || !isset($_FILES['justification'])) {
        header("Location: ../student/home.php?error=invalid");
        exit;
    }
    $session_id = intval($_POST['session_id']);
    $file = $_FILES['justification'];

    // Basic file checks
    $allowed = ['application/pdf','image/jpeg','image/png'];
    if ($file['error'] !== UPLOAD_ERR_OK) {
        header("Location: ../student/home.php?error=upload");
        exit;
    }
    if (!in_array(mime_content_type($file['tmp_name']), $allowed)) {
        header("Location: ../student/home.php?error=type");
        exit;
    }

    // Ensure uploads dir exists
    $uploadDir = __DIR__ . "/../uploads/justifications";
    if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);

    $ext = pathinfo($file['name'], PATHINFO_EXTENSION);
    $fname = sprintf("just_%d_%d.%s", $student_id, time(), $ext);
    $dest = $uploadDir . "/" . $fname;

    if (!move_uploaded_file($file['tmp_name'], $dest)) {
        header("Location: ../student/home.php?error=move");
        exit;
    }

    // Save DB record (pending)
    $stmt = $conn->prepare("INSERT INTO justifications (student_id, session_id, file_path, status) VALUES (?, ?, ?, 'pending')");
    $stmt->execute([$student_id, $session_id, "uploads/justifications/" . $fname]);

    header("Location: ../student/home.php?uploaded=1");
    exit;
}

header("Location: ../student/home.php");
