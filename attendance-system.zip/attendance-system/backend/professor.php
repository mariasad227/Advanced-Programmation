<?php
// backend/professor.php
session_start();
require_once __DIR__ . "/db.php";

// Simple auth check
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'professor') {
    header('HTTP/1.1 403 Forbidden');
    exit('Access denied');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $session_id = intval($_POST['session_id'] ?? 0);
    $attend = $_POST['attend'] ?? [];
    $part = $_POST['part'] ?? [];

    // Basic validation
    if ($session_id <= 0) {
        header("Location: ../professor/home.php?error=invalid_session");
        exit;
    }

    // Save each student's attendance (insert or update)
    $upsert = $conn->prepare("
        INSERT INTO attendance (session_id, student_id, attended, participation)
        VALUES (?, ?, ?, ?)
        ON DUPLICATE KEY UPDATE attended = VALUES(attended), participation = VALUES(participation)
    ");

    foreach ($part as $student_id => $participation) {
        $student_id = intval($student_id);
        $participation = intval($participation);
        $attended = isset($attend[$student_id]) ? 1 : 0;
        $upsert->execute([$session_id, $student_id, $attended, $participation]);
    }

    header("Location: ../professor/session.php?id={$session_id}&saved=1");
    exit;
}

header("Location: ../professor/home.php");
