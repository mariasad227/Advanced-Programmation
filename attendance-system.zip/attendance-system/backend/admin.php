<?php
// backend/admin.php
session_start();
require_once __DIR__ . "/db.php";

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('HTTP/1.1 403 Forbidden');
    exit('Access denied');
}

// Simple router for actions
$action = $_GET['action'] ?? '';

if ($action === 'create_user' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = filter_var($_POST['email'] ?? '', FILTER_VALIDATE_EMAIL);
    $password = $_POST['password'] ?? '';
    $first = trim($_POST['first_name'] ?? '');
    $last = trim($_POST['last_name'] ?? '');
    $role = $_POST['role'] ?? 'student';

    if (!$email || !$password) {
        header("Location: ../admin/students.php?error=invalid");
        exit;
    }
    $hash = password_hash($password, PASSWORD_DEFAULT);
    $stmt = $conn->prepare("INSERT INTO users (email, password, role, first_name, last_name) VALUES (?, ?, ?, ?, ?)");
    $stmt->execute([$email, $hash, $role, $first, $last]);
    header("Location: ../admin/students.php?created=1");
    exit;
}

// other actions like delete/update can be added similarly
header("Location: ../admin/students.php");
