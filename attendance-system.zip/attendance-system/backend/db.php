<?php
// backend/db.php
$host = "localhost";
$dbname = "university_attendance_db";
$user = "root";
$pass = "";

try {
    $conn = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $user, $pass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
    ]);
} catch(PDOException $e){
    die("DB Connection Failed: " . $e->getMessage());
}
