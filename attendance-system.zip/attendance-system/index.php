<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>Login - Attendance System</title>
  <link rel="stylesheet" href="style.css">
</head>
<body class="login-body">
  <div class="container">
    <div class="card" style="max-width:420px;margin:3rem auto;">
      <h2>Attendance System Login TEST</h2>
      <form action="backend/auth.php" method="POST">
        <div class="form-group"><label>Email</label><input type="email" name="email" required></div>
        <div class="form-group"><label>Password</label><input type="password" name="password" required></div>
        <button class="btn" type="submit">Login</button>
      </form>
      <p>TEST MESSAGE VISIBLE</p>
    </div>
  </div>
</body>
</html>