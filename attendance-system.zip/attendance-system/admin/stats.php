<?php
session_start();
require_once __DIR__ . "/../backend/db.php";
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../index.html"); exit;
}
$students = $conn->query("SELECT COUNT(*) FROM users WHERE role='student'")->fetchColumn();
$profs = $conn->query("SELECT COUNT(*) FROM users WHERE role='professor'")->fetchColumn();
?>
<!doctype html>
<html>
<head><meta charset="utf-8"><title>Stats</title><link rel="stylesheet" href="../style.css"></head>
<body>
<header><a href="../backend/logout.php">Logout</a></header>
<main class="container">
  <h2>Statistics</h2>
  <p>Students: <?= $students ?></p>
  <p>Professors: <?= $profs ?></p>
  <!-- For charts: you can add Chart.js and fetch /backend endpoints returning JSON -->
</main>
</body>
</html>
