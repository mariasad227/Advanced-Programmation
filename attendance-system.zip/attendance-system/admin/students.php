<?php
session_start();
require_once __DIR__ . "/../backend/db.php";
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../index.html"); exit;
}
$users = $conn->query("SELECT * FROM users ORDER BY id DESC")->fetchAll(PDO::FETCH_ASSOC);
?>
<!doctype html>
<html>
<head><meta charset="utf-8"><title>Students</title><link rel="stylesheet" href="../style.css"></head>
<body>
<header><a href="../backend/logout.php">Logout</a></header>
<main class="container">
  <h2>Users</h2>
  <table><thead><tr><th>ID</th><th>Name</th><th>Email</th><th>Role</th></tr></thead>
  <tbody>
    <?php foreach($users as $u): ?>
      <tr><td><?= $u['id'] ?></td><td><?= htmlspecialchars($u['first_name'].' '.$u['last_name']) ?></td><td><?= htmlspecialchars($u['email']) ?></td><td><?= $u['role'] ?></td></tr>
    <?php endforeach; ?>
  </tbody></table>

  <h3>Create user</h3>
  <form action="../backend/admin.php?action=create_user" method="POST">
    <input name="email" placeholder="email" required>
    <input name="password" placeholder="password" required>
    <input name="first_name" placeholder="First name">
    <input name="last_name" placeholder="Last name">
    <select name="role"><option value="student">student</option><option value="professor">professor</option><option value="admin">admin</option></select>
    <button class="btn" type="submit">Create</button>
  </form>
</main>
</body>
</html>
