<?php
session_start();
require_once __DIR__ . "/../backend/db.php";
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../index.html");
    exit;
}
// counts
$cntUsers = $conn->query("SELECT COUNT(*) FROM users")->fetchColumn();
?>
<!doctype html>
<html>
<head><meta charset="utf-8"><title>Admin</title><link rel="stylesheet" href="../style.css"></head>
<body>
<header><a href="../backend/logout.php">Logout</a></header>
<main class="container">
  <h2>Admin Dashboard</h2>
  <p>Total users: <?= $cntUsers ?></p>
  <p><a href="students.php">Manage Students</a></p>
  <p><a href="stats.php">Statistics</a></p>
</main>
</body>
</html>
